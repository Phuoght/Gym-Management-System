﻿namespace Gym_Management_System
{
    partial class frm_dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label6 = new Label();
            groupBox1 = new GroupBox();
            lbPT = new Label();
            pictureBox2 = new PictureBox();
            groupBox2 = new GroupBox();
            lbMember = new Label();
            pictureBox1 = new PictureBox();
            groupBox3 = new GroupBox();
            lbReceptionist = new Label();
            pictureBox3 = new PictureBox();
            groupBox4 = new GroupBox();
            lbEquipment = new Label();
            pictureBox4 = new PictureBox();
            lbMemberShip = new Label();
            groupBox5 = new GroupBox();
            lbPromote = new Label();
            pictureBox5 = new PictureBox();
            groupBox6 = new GroupBox();
            pictureBox6 = new PictureBox();
            label7 = new Label();
            lbRevenue = new Label();
            pictureBox7 = new PictureBox();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Red;
            label6.Location = new Point(712, 9);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(238, 54);
            label6.TabIndex = 35;
            label6.Text = "Tổng Quan";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.DarkSeaGreen;
            groupBox1.Controls.Add(lbPT);
            groupBox1.Controls.Add(pictureBox2);
            groupBox1.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.Red;
            groupBox1.Location = new Point(53, 212);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(388, 236);
            groupBox1.TabIndex = 36;
            groupBox1.TabStop = false;
            groupBox1.Text = "Số lượng PT";
            // 
            // lbPT
            // 
            lbPT.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbPT.ForeColor = Color.Red;
            lbPT.Location = new Point(176, 74);
            lbPT.Margin = new Padding(2, 0, 2, 0);
            lbPT.Name = "lbPT";
            lbPT.Size = new Size(158, 111);
            lbPT.TabIndex = 37;
            lbPT.Text = "sl";
            lbPT.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.coach;
            pictureBox2.Location = new Point(28, 60);
            pictureBox2.Margin = new Padding(2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(102, 141);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 37;
            pictureBox2.TabStop = false;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Ivory;
            groupBox2.Controls.Add(lbMember);
            groupBox2.Controls.Add(pictureBox1);
            groupBox2.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.ForeColor = Color.Red;
            groupBox2.Location = new Point(574, 212);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(388, 236);
            groupBox2.TabIndex = 38;
            groupBox2.TabStop = false;
            groupBox2.Text = "Số lượng Thành viên";
            // 
            // lbMember
            // 
            lbMember.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbMember.ForeColor = Color.Red;
            lbMember.Location = new Point(176, 74);
            lbMember.Margin = new Padding(2, 0, 2, 0);
            lbMember.Name = "lbMember";
            lbMember.Size = new Size(158, 111);
            lbMember.TabIndex = 37;
            lbMember.Text = "sl";
            lbMember.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.sportman;
            pictureBox1.Location = new Point(28, 60);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(102, 141);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 37;
            pictureBox1.TabStop = false;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = Color.LightGreen;
            groupBox3.Controls.Add(lbReceptionist);
            groupBox3.Controls.Add(pictureBox3);
            groupBox3.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox3.ForeColor = Color.Red;
            groupBox3.Location = new Point(1115, 212);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(388, 236);
            groupBox3.TabIndex = 38;
            groupBox3.TabStop = false;
            groupBox3.Text = "Số lượng Lễ Tân";
            // 
            // lbReceptionist
            // 
            lbReceptionist.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbReceptionist.ForeColor = Color.Red;
            lbReceptionist.Location = new Point(176, 74);
            lbReceptionist.Margin = new Padding(2, 0, 2, 0);
            lbReceptionist.Name = "lbReceptionist";
            lbReceptionist.Size = new Size(158, 111);
            lbReceptionist.TabIndex = 37;
            lbReceptionist.Text = "sl";
            lbReceptionist.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.receptionist_desk;
            pictureBox3.Location = new Point(28, 60);
            pictureBox3.Margin = new Padding(2);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(102, 141);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 37;
            pictureBox3.TabStop = false;
            // 
            // groupBox4
            // 
            groupBox4.BackColor = Color.LightCyan;
            groupBox4.Controls.Add(lbEquipment);
            groupBox4.Controls.Add(pictureBox4);
            groupBox4.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox4.ForeColor = Color.Red;
            groupBox4.Location = new Point(574, 577);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(388, 236);
            groupBox4.TabIndex = 41;
            groupBox4.TabStop = false;
            groupBox4.Text = "Số lượng Thiết bị";
            // 
            // lbEquipment
            // 
            lbEquipment.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbEquipment.ForeColor = Color.Red;
            lbEquipment.Location = new Point(176, 74);
            lbEquipment.Margin = new Padding(2, 0, 2, 0);
            lbEquipment.Name = "lbEquipment";
            lbEquipment.Size = new Size(158, 111);
            lbEquipment.TabIndex = 37;
            lbEquipment.Text = "sl";
            lbEquipment.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.kettlebell;
            pictureBox4.Location = new Point(28, 60);
            pictureBox4.Margin = new Padding(2);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(102, 141);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 37;
            pictureBox4.TabStop = false;
            // 
            // lbMemberShip
            // 
            lbMemberShip.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbMemberShip.ForeColor = Color.Red;
            lbMemberShip.Location = new Point(176, 74);
            lbMemberShip.Margin = new Padding(2, 0, 2, 0);
            lbMemberShip.Name = "lbMemberShip";
            lbMemberShip.Size = new Size(158, 111);
            lbMemberShip.TabIndex = 37;
            lbMemberShip.Text = "sl";
            lbMemberShip.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // groupBox5
            // 
            groupBox5.BackColor = Color.DeepSkyBlue;
            groupBox5.Controls.Add(lbPromote);
            groupBox5.Controls.Add(pictureBox5);
            groupBox5.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox5.ForeColor = Color.Red;
            groupBox5.Location = new Point(1115, 577);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(388, 236);
            groupBox5.TabIndex = 40;
            groupBox5.TabStop = false;
            groupBox5.Text = "Số lượng Khuyến mãi";
            // 
            // lbPromote
            // 
            lbPromote.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbPromote.ForeColor = Color.Red;
            lbPromote.Location = new Point(176, 74);
            lbPromote.Margin = new Padding(2, 0, 2, 0);
            lbPromote.Name = "lbPromote";
            lbPromote.Size = new Size(158, 111);
            lbPromote.TabIndex = 37;
            lbPromote.Text = "sl";
            lbPromote.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.promo_code;
            pictureBox5.Location = new Point(28, 60);
            pictureBox5.Margin = new Padding(2);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(102, 141);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 37;
            pictureBox5.TabStop = false;
            // 
            // groupBox6
            // 
            groupBox6.BackColor = Color.Honeydew;
            groupBox6.Controls.Add(lbMemberShip);
            groupBox6.Controls.Add(pictureBox6);
            groupBox6.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox6.ForeColor = Color.Red;
            groupBox6.Location = new Point(53, 577);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(388, 236);
            groupBox6.TabIndex = 39;
            groupBox6.TabStop = false;
            groupBox6.Text = "Số lượng Gói tập";
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.inventory_management;
            pictureBox6.Location = new Point(28, 60);
            pictureBox6.Margin = new Padding(2);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(102, 141);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 37;
            pictureBox6.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.Info;
            label7.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Gold;
            label7.Location = new Point(360, 108);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(372, 54);
            label7.TabIndex = 42;
            label7.Text = "Tổng Doanh Thu: ";
            // 
            // lbRevenue
            // 
            lbRevenue.BackColor = SystemColors.Info;
            lbRevenue.Font = new Font("Segoe UI Semibold", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbRevenue.ForeColor = Color.Gold;
            lbRevenue.Location = new Point(768, 108);
            lbRevenue.Margin = new Padding(2, 0, 2, 0);
            lbRevenue.Name = "lbRevenue";
            lbRevenue.Size = new Size(427, 54);
            lbRevenue.TabIndex = 43;
            lbRevenue.Text = "dt";
            lbRevenue.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = SystemColors.Info;
            pictureBox7.Image = Properties.Resources.money;
            pictureBox7.Location = new Point(279, 108);
            pictureBox7.Margin = new Padding(2);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(84, 54);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 38;
            pictureBox7.TabStop = false;
            // 
            // frm_dashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1590, 850);
            Controls.Add(pictureBox7);
            Controls.Add(lbRevenue);
            Controls.Add(label7);
            Controls.Add(groupBox4);
            Controls.Add(groupBox5);
            Controls.Add(groupBox3);
            Controls.Add(groupBox6);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label6);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frm_dashboard";
            Text = "frm_dashboard";
            Load += frm_dashboard_Load;
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label6;
        private GroupBox groupBox1;
        private PictureBox pictureBox2;
        private Label lbPT;
        private GroupBox groupBox2;
        private Label lbMember;
        private PictureBox pictureBox1;
        private GroupBox groupBox3;
        private Label lbReceptionist;
        private PictureBox pictureBox3;
        private GroupBox groupBox4;
        private Label lbEquipment;
        private PictureBox pictureBox4;
        private Label lbMemberShip;
        private GroupBox groupBox5;
        private Label lbPromote;
        private PictureBox pictureBox5;
        private GroupBox groupBox6;
        private PictureBox pictureBox6;
        private Label label7;
        private Label lbRevenue;
        private PictureBox pictureBox7;
    }
}