﻿namespace Gym_Management_System
{
    partial class frm_EditPT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtNameE = new TextBox();
            cbGenE = new ComboBox();
            label2 = new Label();
            txtPhoneE = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            cbExperienceE = new ComboBox();
            txtAddressE = new TextBox();
            label6 = new Label();
            dtpDayOfBirthE = new DateTimePicker();
            label7 = new Label();
            btnSaveE = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(35, 135);
            label1.Name = "label1";
            label1.Size = new Size(117, 38);
            label1.TabIndex = 0;
            label1.Text = "Họ Tên";
            // 
            // txtNameE
            // 
            txtNameE.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNameE.Location = new Point(178, 134);
            txtNameE.Name = "txtNameE";
            txtNameE.Size = new Size(304, 39);
            txtNameE.TabIndex = 1;
            // 
            // cbGenE
            // 
            cbGenE.DropDownStyle = ComboBoxStyle.DropDownList;
            cbGenE.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cbGenE.FormattingEnabled = true;
            cbGenE.Items.AddRange(new object[] { "Nam", "Nữ" });
            cbGenE.Location = new Point(184, 254);
            cbGenE.Name = "cbGenE";
            cbGenE.Size = new Size(182, 40);
            cbGenE.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(20, 249);
            label2.Name = "label2";
            label2.Size = new Size(143, 38);
            label2.TabIndex = 3;
            label2.Text = "Giới Tính";
            // 
            // txtPhoneE
            // 
            txtPhoneE.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPhoneE.Location = new Point(726, 135);
            txtPhoneE.Name = "txtPhoneE";
            txtPhoneE.Size = new Size(188, 39);
            txtPhoneE.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(505, 136);
            label3.Name = "label3";
            label3.Size = new Size(209, 38);
            label3.TabIndex = 5;
            label3.Text = "Số Điện Thoại";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(5, 363);
            label4.Name = "label4";
            label4.Size = new Size(158, 38);
            label4.TabIndex = 7;
            label4.Text = "Ngày Sinh";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(516, 245);
            label5.Name = "label5";
            label5.Size = new Size(198, 38);
            label5.TabIndex = 9;
            label5.Text = "Kinh Nghiệm";
            // 
            // cbExperienceE
            // 
            cbExperienceE.DropDownStyle = ComboBoxStyle.DropDownList;
            cbExperienceE.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cbExperienceE.FormattingEnabled = true;
            cbExperienceE.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" });
            cbExperienceE.Location = new Point(726, 247);
            cbExperienceE.Name = "cbExperienceE";
            cbExperienceE.Size = new Size(182, 40);
            cbExperienceE.TabIndex = 8;
            // 
            // txtAddressE
            // 
            txtAddressE.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAddressE.Location = new Point(726, 358);
            txtAddressE.Name = "txtAddressE";
            txtAddressE.Size = new Size(407, 39);
            txtAddressE.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(556, 356);
            label6.Name = "label6";
            label6.Size = new Size(115, 38);
            label6.TabIndex = 10;
            label6.Text = "Địa Chỉ";
            // 
            // dtpDayOfBirthE
            // 
            dtpDayOfBirthE.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dtpDayOfBirthE.Format = DateTimePickerFormat.Short;
            dtpDayOfBirthE.Location = new Point(184, 363);
            dtpDayOfBirthE.Name = "dtpDayOfBirthE";
            dtpDayOfBirthE.Size = new Size(191, 39);
            dtpDayOfBirthE.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Red;
            label7.Location = new Point(362, 24);
            label7.Name = "label7";
            label7.Size = new Size(426, 48);
            label7.TabIndex = 13;
            label7.Text = "Chỉnh Sửa Thông Tin PT";
            // 
            // btnSaveE
            // 
            btnSaveE.BackColor = Color.Red;
            btnSaveE.Cursor = Cursors.Hand;
            btnSaveE.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSaveE.ForeColor = SystemColors.ButtonFace;
            btnSaveE.Location = new Point(445, 456);
            btnSaveE.Name = "btnSaveE";
            btnSaveE.Size = new Size(148, 53);
            btnSaveE.TabIndex = 15;
            btnSaveE.Text = "Lưu";
            btnSaveE.UseVisualStyleBackColor = false;
            btnSaveE.Click += btnSaveE_Click;
            // 
            // frm_EditPT
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1138, 521);
            Controls.Add(btnSaveE);
            Controls.Add(label7);
            Controls.Add(dtpDayOfBirthE);
            Controls.Add(txtAddressE);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(cbExperienceE);
            Controls.Add(label4);
            Controls.Add(txtPhoneE);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(cbGenE);
            Controls.Add(txtNameE);
            Controls.Add(label1);
            Name = "frm_EditPT";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Chỉnh Sửa Thông Tin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtNameE;
        private ComboBox cbGenE;
        private Label label2;
        private TextBox txtPhoneE;
        private Label label3;
        private Label label4;
        private Label label5;
        private ComboBox cbExperienceE;
        private TextBox txtAddressE;
        private Label label6;
        private DateTimePicker dtpDayOfBirthE;
        private Label label7;
        private Button btnSaveE;
    }
}